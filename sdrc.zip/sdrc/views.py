from django.views.generic import TemplateView

class IndexView(TemplateView):
    template_name = 'sdrc/dashboard.html'
    context_object_name = 'dashboard'

class LoginView(TemplateView):
    template_name = 'sdrc/login.html'
    context_object_name = 'login'