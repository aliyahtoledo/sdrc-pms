from django.apps import AppConfig


class SDRCConfig(AppConfig):
    name = 'sdrc'
